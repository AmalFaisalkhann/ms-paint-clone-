#ifndef DATA_HEADER_FILE
#define DATA_HEADER_FIE

#include "shapes.h"
#include "free_hand_drawing.h"
#include "alphabets.h"
#include "numbers.h"
#include "color.h"
#include "gotoxy.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <windows.h>


#endif