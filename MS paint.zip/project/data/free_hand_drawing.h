void printSymbol(int p, int q, int color,char ch);
void free_hand_drawings(char symbol,char color);