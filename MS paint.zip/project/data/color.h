void set_color(char color);
void reset_color();