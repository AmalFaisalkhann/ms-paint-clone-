struct Shapes{
    int choice;
    int size;
    int rows;
    int columns;
    char borderColor;
    char fillColor;
    char symbol;
    int x;
    int y;
    int length;
    char start;
    char end;
    int radius;
    int height;
    int base;

}

void square_module();
void rectangle_module();
void diamond_module();
void parallelogram_module();
void oval_module();
void line_module();
void triangle_module();
void trapezium_module();
void heart_module();
void hexagon_module();
void star_module();
void arrow_module();
void kite_module();
void chatbox_module();
void butterfly_module();
void circle_module();
void drawing_module();
void alphabets_module();
void numbers_module();
