#ifndef INTERFACE_HEADER_FILE

#include "..\data\data_header.h"
#include "..\brain\brain_header.h"
#include "interface.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <conio.h>
#include <stdlib.h>


#endif