#include "interface_header.h"

void structs(FILE *fptr, struct Shapes *shape, int index)
{
    fprintf(fptr, "Name: %s\n", shape[index].name);
    fprintf(fptr, "Choice: %d\n", shape[index].choice);
    fprintf(fptr, "X Coordinate: %d\n", shape[index].x);
    fprintf(fptr, "Y Coordinate: %d\n", shape[index].y);
    fprintf(fptr, "Size: %d\n", shape[index].size);
    fprintf(fptr, "Length: %d\n", shape[index].length);
    fprintf(fptr, "Symbol: %c\n", shape[index].symbol);
    fprintf(fptr, "Fill Color: %c\n", shape[index].fillColor);
    fprintf(fptr, "Border Color: %c\n", shape[index].borderColor);
    fprintf(fptr, "Radius: %d\n", shape[index].radius);
    fprintf(fptr, "Rows: %d\n", shape[index].rows);
    fprintf(fptr, "Columns: %d\n", shape[index].columns);
    fprintf(fptr, "Height: %d\n", shape[index].height);
    fprintf(fptr, "base: %d\n", shape[index].base);
    fprintf(fptr, "\n"); // Separate records with a newline
}

void square_module()
{
    struct Shapes square[60];
    static int j = 0;

    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Create a filled square\n");
    printf("2. Create a hollow square\n");
    printf("Choice: ");
    scanf(" %d", &square[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &square[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &square[j].y);

    printf("Enter size: ");
    scanf(" %d", &square[j].size);

    printf("Enter symbol: ");
    scanf(" %c", &square[j].symbol);

    if (square[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &square[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &square[j].fillColor);
    }

    else if (square[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &square[j].borderColor);
    }
    strcpy(square[j].name, "square");
    square[j].length = -1;
    square[j].size = square[j].size;
    square[j].rows = -1;
    square[j].columns = -1;
    square[j].fillColor = square[j].fillColor;
    square[j].borderColor = square[j].borderColor;
    square[j].x = square[j].x;
    square[j].y = square[j].y;
    square[j].start = -1;
    square[j].end = -1;
    square[j].symbol = square[j].symbol;
    square[j].radius = -1;
    square[j].height = -1;
    square[j].base = -1;

    structs(fptr, square, j);
    fclose(fptr);
    j++;
    call_square(square[j].choice, square[j].size, square[j].symbol, square[j].borderColor, square[j].fillColor, square[j].x, square[j].y);
}

void rectangle_module()
{
    struct Shapes rectangle[60];
    static int j = 0;
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Create a filled rectangle\n");
    printf("2. Create a hollow rectangle\n");
    printf("Choice: ");
    scanf("%d", &rectangle[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &rectangle[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &rectangle[j].y);

    printf("Enter rows: ");
    scanf("%d", &rectangle[j].rows);

    printf("Enter columns: ");
    scanf("%d", &rectangle[j].columns);

    printf("Enter symbol: ");
    scanf(" %c", &rectangle[j].symbol);
    if (rectangle[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &rectangle[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &rectangle[j].fillColor);
    }

    else if (rectangle[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &rectangle[j].borderColor);
    }

    strcpy(rectangle[j].name, "rectangle");
    rectangle[j].length = -1;
    rectangle[j].size = rectangle[j].size;
    rectangle[j].rows = rectangle[j].rows;
    rectangle[j].columns = rectangle[j].columns;
    rectangle[j].fillColor = rectangle[j].fillColor;
    rectangle[j].borderColor = rectangle[j].borderColor;
    rectangle[j].x = rectangle[j].x;
    rectangle[j].y = rectangle[j].y;
    rectangle[j].start = -1;
    rectangle[j].end = -1;
    rectangle[j].symbol = rectangle[j].symbol;
    rectangle[j].radius = -1;
    rectangle[j].height = -1;
    rectangle[j].base = -1;

    structs(fptr, rectangle, j);
    fclose(fptr);
    j++;
    call_rectangle(rectangle[j].choice, rectangle[j].rows, rectangle[j].columns, rectangle[j].symbol, rectangle[j].borderColor, rectangle[j].fillColor, rectangle[j].x, rectangle[j].y);
}

void diamond_module()
{
    struct Shapes diamond[60];
    static int j = 0;
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Create a filled diamond\n");
    printf("2. Create a hollow diamond\n");

    scanf("%d", &diamond[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &diamond[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &diamond[j].y);

    printf("Enter the size of the diamond: ");
    scanf("%d", &diamond[j].size);

    printf("Enter symbol: ");
    scanf(" %c", &diamond[j].symbol);

    if (diamond[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &diamond[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &diamond[j].fillColor);
    }

    else if (diamond[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &diamond[j].borderColor);
    }

    strcpy(diamond[j].name, "diamond");
    diamond[j].length = -1;
    diamond[j].size = diamond[j].size;
    diamond[j].rows = -1;
    diamond[j].columns = -1;
    diamond[j].fillColor = diamond[j].fillColor;
    diamond[j].borderColor = diamond[j].borderColor;
    diamond[j].x = diamond[j].x;
    diamond[j].y = diamond[j].y;
    diamond[j].start = -1;
    diamond[j].end = -1;
    diamond[j].symbol = diamond[j].symbol;
    diamond[j].radius = -1;
    diamond[j].height = -1;
    diamond[j].base = -1

    structs(fptr, diamond, j);
    fclose(fptr);
    j++;

    call_diamond(diamond[j].choice, diamond[j].size, diamond[j].symbol, diamond[j].borderColor, diamond[j].fillColor, diamond[j].x, diamond[j].y);
}

void oval_module()
{
    struct Shapes oval[60];
    static int j = 0; 

    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    printf("Select an option:\n");
    printf("1. Create a filled oval\n");
    printf("2. Create a hollow oval\n");
    scanf(" %d", &oval[j].choice);

    if (oval[j].choice != 1 || oval[j].choice != 2)
    {
        printf("Invalid choice!");
    }

    printf("Enter x coordinate: ");
    scanf("%d", &oval[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &oval[j].y);

    printf("Enter the radius: ");
    scanf("%d", &oval[j].radius);

    printf("Enter symbol: ");
    scanf(" %c", &oval[j].symbol);

    if (oval[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &oval[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &oval[j].fillColor);
    }

    else if (oval[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &oval[j].borderColor);
    }

    strcpy(oval[j].name, "oval");
    oval[j].length = -1;
    oval[j].size = oval[j].size;
    oval[j].rows = -1;
    oval[j].columns = -1;
    oval[j].borderColor = oval[j].borderColor;
    oval[j].borderColor = oval[j].borderColor;
    oval[j].x = oval[j].x;
    oval[j].y = oval[j].y;
    oval[j].start = -1;
    oval[j].end = -1;
    oval[j].symbol = oval[j].symbol;
    oval[j].radius = oval[j].radiu;
    oval[j].height = -1;
    oval[j].base = -1;

    structs(fptr, oval, j);
    fclose(fptr);
    j++;
    call_oval(oval[j].choice, oval[j].radius, oval[j].symbol, oval[j].borderColor, oval[j].fillColor, oval[j].x, oval[j].y);
}

void line_module()
{
    struct Shapes line[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Enter x coordinate: ");
    scanf("%d", &line[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &line[j].y);

    printf("Enter the symbol: ");
    scanf(" %c", &line[j].symbol);

    printf("Enter color (r/g/b/y/w): ");
    scanf(" %c", &line[j].borderColor);

    printf("Enter the length: ");
    scanf("%d", &line[j].length);

    printf("Enter 1 for vertical, 0 for horizontal: ");
    scanf("%d", &line[j].choice);

    strcpy(line[j].name, "line");
    line[j].length = line[j].length;
    line[j].size = -1;
    line[j].rows = -1;
    line[j].columns = -1;
    line[j].fillColor = -1;
    line[j].borderColor = line[j].borderColor;
    line[j].x = line[j].x;
    line[j].y = line[j].y;
    line[j].start = -1;
    line[j].end = -1;
    line[j].symbol = line[j].symbol;
    line[j].radius = -1;
    line[j].height = -1;
    line[j].base = -1;

    structs(fptr, line, j);
    fclose(fptr);
    j++;
    call_line(line[j].symbol, line[j].length, line[j].choice, line[j].borderColor, line[j].x, line[j].y);
}

void triangle_module()
{
    struct Shapes triangle[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    printf("Select a shape:\n");
    printf("1. Increasing Triangle\n");
    printf("2. inverted increasing Triangle\n");
    printf("3. inverted decreasing Triangle\n");
    printf("4.  Decreasing Triangle\n");
    printf("5. Hollow Increasing Triangle\n");
    printf("6. Hollow Decreasing Triangle\n");
    printf("7. Inverted Hollow Increasing Triangle\n");
    printf("8. Inverted Hollow Decreasing Triangle\n");
    scanf("%d", &triangle[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &triangle[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &triangle[j].y);

    printf("Enter size: ");
    scanf(" %d", &triangle[j].size);

    printf("Enter symbol: ");
    scanf(" %c", &triangle[j].symbol);

    if (triangle[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].fillColor);
    }

    else if (triangle[j].choice == 2)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].fillColor);
    }

    else if (triangle[j].choice == 3)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].fillColor);
    }

    else if (triangle[j].choice == 4)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].fillColor);
    }

    else if (triangle[j].choice == 5)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
    }

    else if (triangle[j].choice == 6)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
    }

    else if (triangle.choice == 7)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
    }

    else if (triangle[j].choice == 8)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &triangle[j].borderColor);
    }

    strcpy(triangle[j].name, "triangle");
    triangle[j].length = -1;
    triangle[j].size = triangle[j].size;
    triangle[j].rows = -1;
    triangle[j].columns = -1;
    triangle[j].fillColor = triangle[j].fillColor;
    triangle[j].borderColor = triangle[j].borderColor;
    triangle[j].x = triangle[j].x;
    triangle[j].y = triangle[j].y;
    triangle[j].start = -1;
    triangle[j].end = -1;
    triangle[j].symbol = triangle[j].symbol;
    triangle[j].radius = -1;
    triangle[j].height = -1;
    triangle[j].base = -1;

    structs(fptr, triangle, j);
    fclose(fptr);
    j++;
    call_triangle(triangle[j].choice, triangle[j].size, triangle[j].fillColor, triangle[j].borderColor, triangle[j].symbol, triangle[j].x, triangle[j].y);
}

void trapezium_module()
{
    struct Shapes trapezium[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Choose a trapezium pattern:\n");
    printf("1. Filled Trapezium\n");
    printf("2. Hollow Trapezium\n");
    printf("Enter your choice (1 or 2): ");
    scanf("%d", &trapezium[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &trapezium[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &trapezium[j].y);

    printf("Enter the height: ");
    scanf(" %d", &trapezium[j].height);
    printf("Enter the base: ");
    scanf(" %d", &trapezium[j].base);

    printf("Enter the symbol: ");
    scanf(" %c", &trapezium[j].symbol);

    if (trapezium[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &trapezium[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &trapezium[j].fillColor);
    }

    else if (trapezium[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &trapezium[j].borderColor);
    }
    // you have to correct this
    strcpy(trapezium[j].name, "trapezium");
    trapezium[j].length = -1;
    trapezium[j].size = trapezium[j].size;
    trapezium[j].rows = -1;
    trapezium[j].columns = -1;
    trapezium[j].fillColor = trapezium[j].fillColor;
    trapezium[j].borderColor = trapezium[j].borderColor;
    trapezium[j].x = trapezium[j].x;
    trapezium[j].y = trapezium[j].y;
    trapezium[j].start = -1;
    trapezium[j].end = -1;
    trapezium[j].symbol = trapezium[j].symbol;
    trapezium[j].radius = -1;
    trapezium[j].height = trapezium[j].height;
    trapezium[j].base = trapezium[j].base;

    structs(fptr, trapezium, j);
    fclose(fptr);
    j++;
    // yr ma ne   height ki jaga size likh dia ha  ab mjhe nhi pata to ne kon sa  use krna ha word height ya size dekh len
    call_trapezium(trapezium[j].choice, trapezium[j].height, trapezium[j].base, trapezium[j].symbol, trapezium[j].borderColor, trapezium[j].fillColor, trapezium[j].x, trapezium[j].y);
}

void hexagon_module()
{
    struct Shapes hexagon[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    printf("Choose a hexagon pattern:\n");
    printf("1. Filled Hexagon\n");
    printf("2. Hollow Hexagon\n");
    printf("Enter your choice (1 or 2): ");
    scanf("%d", &hexagon[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &hexagon[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &hexagon[j].y);

    printf("Enter height: ");
    scanf("%d", &hexagon[j].height);

    printf("Enter base: ");
    scanf("%d", &hexagon[j].base);

    printf("Enter symbol: ");
    scanf(" %c", &hexagon[j].symbol);

    if (hexagon[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &hexagon[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &hexagon[j].fillColor);
    }

    else if (hexagon[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &hexagon[j].borderColor);
    }

    strcpy(hexagon[j].name, "hexagon");
    hexagon[j].length = -1;
    hexagon[j].size = hexagon[j].size;
    hexagon[j].rows = -1;
    hexagon[j].columns = -1;
    hexagon[j].fillColor = hexagon[j].fillColor;
    hexagon[j].borderColor = hexagon[j].borderColor;
    hexagon[j].x = hexagon[j].x;
    hexagon[j].y = hexagon[j].y;
    hexagon[j].start = -1;
    hexagon[j].end = -1;
    hexagon[j].symbol = hexagon[j].symbol;
    hexagon[j].radius = -1;
    hexagon[j].height = trapezium[j].height;
    hexagon[j].base = trapezium[j].base;

    structs(fptr, hexagon, j);
    fclose(fptr);
    j++;
    call_hexagon(hexagon[j].choice, hexagon[j].height, hexagon[j].base, hexagon[j].symbol, hexagon[j].borderColor, hexagon[j].fillColor, hexagon[j].x, hexagon[j].y);
}

void heart_module()
{
    struct Shapes heart[60];
    static int j = 0; 

    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    printf("Select an option:\n");
    printf("1. Create a Filled Heart\n");
    printf("2. Create a Hollow Heart\n");
    printf("Choice: ");
    scanf(" %d", &heart[j].choice);

    if (heart[j].choice != 1 || heart[j].choice != 2)
    {
        printf("Invalid choice!");
    }

    printf("Enter x coordinate: ");
    scanf("%d", &heart[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &heart[j].y);

    printf("Enter the size of the heart: ");
    scanf("%d", &heart[j].size);

    printf("Enter the symbol you want to use: ");
    scanf(" %c", &heart[j].symbol);

    if (heart[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &heart[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &heart[j].fillColor);
    }

    else if (heart[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &heart[j].borderColor);
    }

    strcpy(heart[j].name, "heart");
    heart[j].length = -1;
    heart[j].size = heart[j].size;
    heart[j].rows = -1;
    heart[j].columns = -1;
    heart[j].fillColor = heart[j].fillColor;
    heart[j].borderColor = heart[j].borderColor;
    heart[j].x = heart[j].x;
    heart[j].y = heart[j].y;
    heart[j].start = -1;
    heart[j].end = -1;
    heart[j].symbol = heart[j].symbol;
    heart[j].radius = -1;
    heart[j].height = -1;
    heart[j].base = -1;

    structs(fptr, heart, j);
    fclose(fptr);
    j++;
    call_heart(heart[j].choice, heart[j].size, heart[j].symbol, heart[j].borderColor, heart[j].fillColor, heart[j].x, heart[j].y);
}

void arrow_module()
{
    struct Shapes arrow[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Up Arrow\n");
    printf("2. Down Arrow\n");
    printf("3. left Arrow\n");
    printf("4. rightArrow\n");
    printf("Choice: ");
    scanf(" %d", &arrow[j].choice);

    if (arrow[j].choice != 1 || arrow[j].choice != 2)
    {
        printf("Invalid choice!");
    }

    printf("Enter x coordinate: ");
    scanf("%d", &arrow[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &arrow[j].y);

    printf("Enter the size of the arrows: ");
    scanf("%d", &arrow[j].size);

    printf("Enter the symbol for the arrow: ");
    scanf(" %c", &arrow[j].symbol);

    printf("Enter color (r/g/b/y/w): ");
    scanf(" %c", &arrow[j].borderColor);

    strcpy(arrow[j].name, "arrow");
    arrow[j].length = -1;
    arrow[j].size = arrow[j].size;
    arrow[j].rows = -1;
    arrow[j].columns = -1;
    arrow[j].fillColor = -1;
    arrow[j].borderColor = arrow[j].borderColor;
    arrow[j].x = arrow[j].x;
    arrow[j].y = arrow[j].y;
    arrow[j].start = -1;
    arrow[j].end = -1;
    arrow[j].symbol = arrow[j].symbol;
    arrow[j].radius = -1;
    arrow[j].height = -1;
    arrow[j].base = -1;

    structs(fptr, arrow, j);
    fclose(fptr);
    j++;
    call_arrow(arrow.choice[j], arrow[j].size, arrow[j].symbol, arrow[j].borderColor, arrow[j].x, arrow[j].y);
}

void star_module()
{
    struct Shapes star[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    printf("Enter x coordinate: ");
    scanf("%d", &star[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &star[j].y);

    printf("Enter size: ");
    scanf("%d", &star[j].size);

    printf("Enter symbol: ");
    scanf(" %c", &star[j].symbol);

    printf("Enter color (r/g/b/y/w): ");
    scanf(" %c", &star[j].borderColor);

    strcpy(star[j].name, "star");
    star[j].length = -1;
    star[j].size = star[j].size;
    star[j].rows = -1;
    star[j].columns = -1;
    star[j].fillColor = -1;
    star[j].borderColor = star[j].borderColor;
    star[j].x = star[j].x;
    star[j].y = star[j].y;
    star[j].start = -1;
    star[j].end = -1;
    star[j].symbol = star[j].symbol;
    star[j].radius = -1;
    star[j].height = -1;
    star[j].base = -1;

    structs(fptr, star, j);
    fclose(fptr);
    j++;
    call_star(star[j].size, star[j].symbol, star[j].borderColor, star[j].x, star[j].y);
}

void kite_module()
{
    struct Shapes kite[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Create a filled kite\n");
    printf("2. Create a hollow kite\n");
    printf("Choice: ");
    scanf("%d", &kite[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &kite[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &kite[j].y);

    printf("Enter size: \n");
    scanf("%d", &kite[j].size);

    printf("Enter symbol: \n");
    scanf(" %c", &kite[j].symbol);

    if (kite[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &kite[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &kite[j].fillColor);
    }

    else if (kite[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &kite[j].borderColor);
    }

    strcpy(kite[j].name, "kite");
    kite[j].length = -1;
    kite[j].size = kite[j].size;
    kite[j].rows = -1;
    kite[j].columns = -1;
    kite[j].fillColor = kite[j].fillColor;
    kite[j].borderColor = kite[j].borderColor;
    kite[j].x = kite[j].x;
    kite[j].y = kite[j].y;
    kite[j].start = -1;
    kite[j].end = -1;
    kite[j].symbol = kite[j].symbol;
    kite[j].radius = -1;
    kite[j].height = -1;
    kite[j].base = -1;


    structs(fptr, kite, j);
    fclose(fptr);
    j++;
    call_kite(kite[j].choice, kite[j].size, kite[j].symbol, kite[j].borderColor, kite[j].fillColor, kite[j].x, kite[j].y);
}

void chatbox_module()
{
    struct Shapes chatbox[60];
    static int j = 0;  

    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Create a filled chatbox\n");
    printf("2. Create a hollow chatbox\n");
    printf("Choice: ");
    scanf("%d", &chatbox[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &chatbox[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &chatbox[j].y);

    printf("Enter rows: ");
    scanf("%d", &chatbox[j].rows);

    printf("Enter columns: ");
    scanf("%d", &chatbox[j].columns);

    printf("Enter symbol: ");
    scanf(" %c", &chatbox[j].symbol);

    if (chatbox[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &chatbox[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &chatbox[j].fillColor);
    }

    else if (chatbox[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &chatbox[j].borderColor);
    }
    strcpy(chatbox[j].name, "chatbox");
    chatbox[j].length = -1;
    chatbox[j].size = -1;
    chatbox[j].rows = chatbox[j].rows;
    chatbox[j].columns = chatbox[j].columns;
    chatbox[j].fillColor = chatbox[j].fillColor;
    chatbox[j].borderColor = chatbox[j].borderColor;
    chatbox[j].x = chatbox[j].x;
    chatbox[j].y = chatbox[j].y;
    chatbox[j].start = -1;
    chatbox[j].end = -1;
    chatbox[j].symbol = chatbox[j].symbol;
    chatbox[j].radius = -1;
    chatbox[j].height = -1;
    chatbox[j].base = -1;

    structs(fptr, chatbox, j);
    fclose(fptr);
    j++;
    call_chatbox(chatbox[j].choice, chatbox[j].rows, chatbox[j].columns, chatbox[j].symbol, chatbox[j].borderColor, chatbox[j].fillColor, chatbox[j].x, chatbox[j].y);
}

void parallelogram_module()
{
    struct Shapes parallelogram[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Select an option:\n");
    printf("1. Create a filled parallelogram\n");
    printf("2. Create a hollow parallelogram\n");
    scanf(" %d", &parallelogram[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &parallelogram[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &parallelogram[j].y);

    printf("Enter the number of rows: ");
    scanf(" %d", &parallelogram[j].rows);

    printf("Enter the number of columns: ");
    scanf(" %d", &parallelogram[j].columns);

    printf("Enter symbol: ");
    scanf(" %c", &parallelogram[j].symbol);

    if (parallelogram[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &parallelogram[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &parallelogram[j].fillColor);
    }

    else if (parallelogram[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &parallelogram[j].borderColor);
    }

    strcpy(parallelogram[j].name, "parallelogram");
    parallelogram[j].length = -1;
    parallelogram[j].size = -1;
    parallelogram[j].rows = parallelogram[j].rows;
    parallelogram[j].columns = parallelogram[j].columns;
    parallelogram[j].fillColor = parallelogram[j].fillColor;
    parallelogram[j].borderColor = parallelogram[j].borderColor;
    parallelogram[j].x = parallelogram[j].x;
    parallelogram[j].y = parallelogram[j].y;
    parallelogram[j].start = -1;
    parallelogram[j].end = -1;
    parallelogram[j].symbol = parallelogram[j].symbol;
    parallelogram[j].radius = -1;
    parallelogram[j].height = -1;
    parallelogram[j].base = -1;


    structs(fptr, parallelogram, j);
    fclose(fptr);
    j++;
    call_parallelogram(parallelogram[j].choice, parallelogram[j].rows, parallelogram[j].columns, parallelogram[j].symbol, parallelogram[j].borderColor, parallelogram[j].fillColor, parallelogram[j].x, parallelogram[j].y);
}

void butterfly_module()
{
    struct Shapes butterfly[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    // Prompt the user to choose the butterfly pattern type
    printf("Choose a butterfly pattern type:\n");
    printf("1. Filled Butterfly\n");
    printf("2. Hollow Butterfly\n");
    printf("Enter your choice (1/2): ");
    scanf("%d", &butterfly[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &butterfly[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &butterfly[j].y);

    printf("Enter the size of the filled butterfly: ");
    scanf("%d", &butterfly[j].size);
    printf("Enter the symbol of the filled butterfly: ");
    scanf(" %c", &butterfly[j].symbol);

    if (butterfly[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &butterfly[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &butterfly[j].fillColor);
    }

    else if (butterfly[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &butterfly[j].borderColor);
    }

    strcpy(butterfly[j].name, "butterfly");
    butterfly[j].length = -1;
    butterfly[j].size = butterfly[j].size;
    butterfly[j].rows = -1;
    butterfly[j].columns = -1;
    butterfly[j].fillColor = butterfly[j].fillColor;
    butterfly[j].borderColor = butterfly[j].borderColor;
    butterfly[j].x = butterfly[j].x;
    butterfly[j].y = butterfly[j].y;
    butterfly[j].start = -1;
    butterfly[j].end = -1;
    butterfly[j].symbol = butterfly[j].symbol;
    butterfly[j].radius = -1;
    butterfly[j].height = -1;
    butterfly[j].base = -1;

    structs(fptr, butterfly, j);
    fclose(fptr);
    j++;
    call_butterfly(butterfly[j].choice, butterfly[j].size, butterfly[j].symbol, butterfly[j].borderColor, butterfly[j].fillColor, butterfly[j].x, butterfly[j].y);
}

void circle_module()
{
    struct Shapes circle[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("1. Filled Circle\n");
    printf("2. Hollow Circle\n");
    printf("Enter your choice (1/2): ");
    scanf("%d", &circle[j].choice);

    printf("Enter x coordinate: ");
    scanf("%d", &circle[j].x);

    printf("Enter y coordinate: ");
    scanf("%d", &circle[j].y);

    printf("Enter size: ");
    scanf("%d", &circle[j].size);

    printf("Enter shape symbol: ");
    scanf(" %c", &circle[j].symbol);

    if (circle[j].choice == 1)
    {
        printf("Enter border color (r/g/b/y/w): ");
        scanf(" %c", &circle[j].borderColor);
        printf("Enter fill color (r/g/b/y/w): ");
        scanf(" %c", &circle[j].fillColor);
    }

    else if (circle[j].choice == 2)
    {
        printf("Enter color (r/g/b/y/w): ");
        scanf(" %c", &circle[j].borderColor);
    }

    strcpy(circle[j].name, "circle");
    circle[j].length = -1;
    circle[j].size = circle[j].size;
    circle[j].rows = -1;
    circle[j].columns = -1;
    circle[j].fillColor = circle[j].fillColor;
    circle[j].borderColor = circle[j].borderColor;
    circle[j].x = circle[j].x;
    circle[j].y = circle[j].y;
    circle[j].start = -1;
    circle[j].end = -1;
    circle[j].symbol = circle[j].symbol;
    circle[j].radius = circle[j].radius;
    circle[j].height = -1;
    circle[j].base = -1;

    structs(fptr, circle, j);
    fclose(fptr);
    j++;
    call_circle(circle[j].choice, circle[j].size, circle[j].symbol, circle[j].borderColor, circle[j].fillColor, circle[j].x, circle[j].y);
}

void drawing_module()
{
    struct Shapes draw[60];
    static int j = 0; 

    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }
    printf("Enter a Symbol: ");
    scanf(" %c", &draw[j].symbol);

    printf("Enter a color (r/g/b/y/w): ");
    scanf(" %c", &draw[j].fillColor); // change

    strcpy(draw[j].name, "draw");
    draw[j].length = -1;
    draw[j].size = draw[j].size;
    draw[j].rows = -1;
    draw[j].columns = -1;
    draw[j].fillColor = -1;
    draw[j].borderColor = -1;
    draw[j].x = -1;
    draw[j].y = -1;
    draw[j].start = -1;
    draw[j].end = -1;
    draw[j].symbol = draw[j].symbol;
    draw[j].radius = -1;
    draw[j].height = -1;
    draw[j].base = -1;

    structs(fptr, draw, j);
    fclose(fptr);
    j++;
    call_drawing(draw[j].symbol, draw[j].fillColor);
}

void alphabets_module()
{
    struct Shapes alphabets[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Enter the symbol you want to print in your screen =\n"); // Statement To Get THe Symbol From The User
    scanf(" %c", &alphabets[j].symbol);
    printf("Enter size =\n");
    scanf("%d", &alphabets[j].size);
    printf("Enter the color of the symbol you want to print in your screen =\n"); // Statement To Get THe Color From The User
    scanf(" %c", &alphabets[j].color);
    printf("Enter x-axis =\n");
    scanf("%d", &alphabets[j].x);
    printf("Enter y-axis =\n");
    scanf("%d", &alphabets[j].y);
    printf("Enter '0' for printing all alphabets \n Enter '1' for printing alphabets in a range \n");
    scanf("%d", &alphabets[j].choice);
    printf("enter the first alphabet of your range \n");
    alphabets[j].start = getch();
    printf("enter the last alphabet of your range \n");
    alphabets[j].end = getch();
    printf("Character you entered, are  %c and  %c \n", alphabets[j].start, alphabets[j].end);

    strcpy(alphabets[j].name, "alphabets");
    alphabets[j].length = -1;
    alphabets[j].size = alphabets[j].size;
    alphabets[j].rows = -1;
    alphabets[j].columns = -1;
    alphabets[j].fillColor = -1;
    alphabets[j].borderColor = alphabets[j].borderColor;
    alphabets[j].x = alphabets[j].x;
    alphabets[j].y = alphabets[j].y;
    alphabets[j].start = alphabets[j].start;
    alphabets[j].end = alphabets[j].end;
    alphabets[j].symbol = alphabets[j].symbol;
    alphabets[j].radius = -1;
    alphabets[j].height = -1;
    alphabets[j].base = -1;

    structs(fptr, alphabets, j);
    fclose(fptr); 
    j++;
    call_alphabets(alphabets[j].symbol, alphabets[j].borderColor, alphabets[j].x, alphabets[j].y, alphabets[j].size, alphabets[j].choice, alphabets[j].start, alphabets[j].end);
}

void numbers_module()
{
    struct Shapes numbers[60];
    static int j = 0; 
    FILE *fptr = fopen("data.txt", "a");
    if (fptr == NULL)
    {
        perror("Error opening file for appending");
        return;
    }

    printf("Enter the symbol you want to print in your screen =\n"); // Statement To Get THe Symbol From The User
    scanf(" %c", &numbers[j].symbol);
    printf("Enter size =\n");
    scanf("%d", &numbers[j].size);
    printf("Enter the color of the symbol you want to print in your screen =\n"); // Statement To Get THe Color From The User
    scanf(" %c", &numbers[j].color);
    printf("Enter x-axis =\n");
    scanf("%d", &numbers[j].x);
    printf("Enter y-axis =\n");
    scanf("%d", &numbers[j].y);
    printf("Enter '0' for printing all alphabets \n Enter '1' for printing alphabets in a range \n");
    scanf("%d", &numbers[j].choice);
    printf("enter the first number of your range \n");
    scanf("%d", &numbers[j].start);
    printf("enter the last number of your range \n");
    scanf("%d", &numbers[j].end);

    strcpy(numbers[j].name, "numbers");
    numbers[j].length = -1;
    numbers[j].size = numbers[j].size;
    numbers[j].rows = -1;
    numbers[j].columns = -1;
    numbers[j].fillColor = -1;
    numbers[j].borderColor = numbers[j].borderColor;
    numbers[j].x = numbers[j].x;
    numbers[j].y = numbers[j].y;
    numbers[j].start = numbers[j].start;
    numbers[j].end = numbers[j].end;
    numbers[j].symbol = numbers[j].symbol;
    numbers[j].radius = -1;
    numbers[j].height = -1;
    numbers[j].base = -1;

    structs(fptr, numbers, j);
    fclose(fptr);
    j++;
    call_numbers(numbers[j].symbol, numbers[j].borderColor, numbers[j].x, numbers[j].y, numbers[j].size, numbers[j].choice, numbers[j].start, numbers[j].end);
}

void savefile()
{
    char ch;
    fptr = fopen("automatic.txt", "r");
    fclose(fptr);
    FILE *fptr2;
    char file_name[100];
    printf("Enter file name: ");
    gets(file_name);
    gets(file_name);
    strcat(file_name, ".txt");
    fptr2 = fopen(file_name, "w"); // Use "a" mode for appending/creating

    if (fptr2 == NULL)
    {
        printf("Error creating/appending the file");
    }
    while ((ch = fgetc(fptr)) != EOF)
    {
        fputc(ch, fptr2);
    }
    fclose(fptr2);
}

void autosave()
{
    FILE *fptr = NULL;
    fptr = fopen("data.txt.txt", "a");
    structs(fptr, &Shapes);
    fclose(fptr);
}